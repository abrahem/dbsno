<?php
$themename = "Ar Moviz";
define( 'OPTIONS_FRAMEWORK_DIRECTORY', get_template_directory_uri() . '/admincp/' );
require_once dirname( __FILE__ ) . '/admincp/options-framework.php';
$optionsfile = locate_template( 'options.php' );
load_template( $optionsfile );

require TEMPLATEPATH . '/metabox/meta-box.php';
require TEMPLATEPATH . '/metabox/theme_metaboxes.php';



function getPostViews($postID){ 
    $count_key = 'post_views_count'; 
    $count = get_post_meta($postID, $count_key, true); 
    if($count==''){ 
        delete_post_meta($postID, $count_key); 
        add_post_meta($postID, $count_key, '0'); 
        return "0 View"; 
    } 
    return $count.' Views'; 
} 
function setPostViews($postID) { 
    $count_key = 'post_views_count'; 
    $count = get_post_meta($postID, $count_key, true); 
    if($count==''){ 
        $count = 0; 
        delete_post_meta($postID, $count_key); 
        add_post_meta($postID, $count_key, '0'); 
    }else{ 
        $count++; 
        update_post_meta($postID, $count_key, $count); 
    } 
} 
/*-----------------------------------------------------------------------------------*/
# Featured images #احجام الصور حسب الDiv
/*-----------------------------------------------------------------------------------*/

add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size(800);

add_image_size( 'card-home', 299, 350 );



function get_category_id($cat_name){
	$term = get_term_by('name', $cat_name, 'category');
	return $term->term_id;
}

/*-----------------------------------------------------------------------------------*/
# Pagination #تعدد الصفحات
/*-----------------------------------------------------------------------------------*/
//
function get_number_posts(){
$numpost = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status = 'publish' AND post_type = 'post'"); echo $numpost;
}

function pagination($pages = '', $range = 3)
{
$showitems = ($range * 2)+1; 

global $paged;
if(empty($paged)) $paged = 1;

if($pages == '')
{
global $wp_query;
$pages = $wp_query->max_num_pages;
if(!$pages)
{
$pages = 1;
}
}  

////////////////////////
if(1 != $pages)
{
echo "<div class=\"pagination\">";
if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo; الاولى</a>";
if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo; السابق</a>";

for ($i=1; $i <= $pages; $i++)
{
if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
{
echo ($paged == $i)? "<span class=\"current\">".$i."</span>":"<a href='".get_pagenum_link($i)."' class=\"inactive\">".$i."</a>";
}
}

if ($paged < $pages && $showitems < $pages) echo "<a href=\"".get_pagenum_link($paged + 1)."\">التالى &rsaquo;</a>";
if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>الاخيره &raquo;</a>";
echo "</div>\n";
}
}  

/*-----------------------------------------------------------------------------------*/
# Excerpt #تقليص طول الوصف
/*-----------------------------------------------------------------------------------*/

function excerpt($limit) {
 $excerpt = explode(' ', get_the_excerpt(), $limit);
 if (count($excerpt)>=$limit) {
 array_pop($excerpt);
 $excerpt = implode(" ",$excerpt).'...';
 } else {
 $excerpt = implode(" ",$excerpt);
 }
 $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
 return $excerpt;
}



add_action( 'load-post.php', 'safe_post_meta_boxes_setup' );
add_action( 'load-post-new.php', 'safe_post_meta_boxes_setup' );
function safe_post_meta_boxes_setup() {

  /* Add meta boxes on the 'add_meta_boxes' hook. */
  add_action( 'add_meta_boxes', 'safe_add_post_meta_boxes' );
    add_action( 'save_post', 'safe_save_post_class_meta', 10, 2 );
}
function safe_add_post_meta_boxes() {

  add_meta_box(
    'safe-post-class',      // Unique ID
    esc_html__( 'Post Class', 'example' ),    // Title
    'safe_post_class_meta_box',   // Callback function
    'post',         // Admin page (or post type)
    'side',         // Context
    'default'         // Priority
  );
}
function safe_post_class_meta_box( $post ) { ?>

  <?php wp_nonce_field( basename( __FILE__ ), 'safe_post_class_nonce' ); ?>

  <p>
    <label for="safe-post-class"><?php _e( "Add a custom CSS class, which will be applied to WordPress' post class.", 'example' ); ?></label>
    <br />
    <input class="widefat" type="text" name="safe-post-class" id="safe-post-class" value="<?php echo esc_attr( get_post_meta( $post->ID, 'safe_post_class', true ) ); ?>" size="30" />
  </p>
<?php }

function safe_save_post_class_meta( $post_id, $post ) {

  /* Verify the nonce before proceeding. */
  if ( !isset( $_POST['safe_post_class_nonce'] ) || !wp_verify_nonce( $_POST['safe_post_class_nonce'], basename( __FILE__ ) ) )
    return $post_id;

  /* Get the post type object. */
  $post_type = get_post_type_object( $post->post_type );

  /* Check if the current user has permission to edit the post. */
  if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
    return $post_id;

  /* Get the posted data and sanitize it for use as an HTML class. */
  $new_meta_value = ( isset( $_POST['safe-post-class'] ) ? sanitize_html_class( $_POST['safe-post-class'] ) : '' );

  /* Get the meta key. */
  $meta_key = 'safe_post_class';

  /* Get the meta value of the custom field key. */
  $meta_value = get_post_meta( $post_id, $meta_key, true );

  /* If a new meta value was added and there was no previous value, add it. */
  if ( $new_meta_value && '' == $meta_value )
    add_post_meta( $post_id, $meta_key, $new_meta_value, true );

  /* If the new meta value does not match the old value, update it. */
  elseif ( $new_meta_value && $new_meta_value != $meta_value )
    update_post_meta( $post_id, $meta_key, $new_meta_value );

  /* If there is no new meta value but an old value exists, delete it. */
  elseif ( '' == $new_meta_value && $meta_value )
    delete_post_meta( $post_id, $meta_key, $meta_value );
}
add_filter( 'post_class', 'safe_post_class' );

function safe_post_class( $classes ) {

  /* Get the current post ID. */
  $post_id = get_the_ID();

  /* If we have a post ID, proceed. */
  if ( !empty( $post_id ) ) {

    /* Get the custom post class. */
    $post_class = get_post_meta( $post_id, 'safe_post_class', true );

    /* If a post class was input, sanitize it and add it to the post class array. */
    if ( !empty( $post_class ) )
      $classes[] = sanitize_html_class( $post_class );
  }

  return $classes;
}













?>