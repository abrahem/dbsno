<? get_header(); ?>

<div class="pagepad">
<div class="row">
<div class="card-movies">

<h4>
<?php single_cat_title(); ?>
</h4>

</div><!--h-block-->


<? /*Begin Content area Query*/ ?>
<?php if (have_posts()) : ?>
  <?php while (have_posts()) : the_post(); ?>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6" style="margin-bottom: 20px;">
<div class="card-home">

<a href="<?php the_permalink(); ?>">
<?php the_post_thumbnail(); ?>

<div class="row col-lg-12">
<h4><i class="fa fa-film"></i>  <?php the_title(); ?></h4>
</div>
</a>
</div><!---/card-home--->
</div>	


<?php endwhile; ?>

  <div class="clearfix"></div>
  
<div class="num-page">
<div class="row">
<?php if (function_exists("pagination")) {
		 pagination($additional_loop->max_num_pages);
		 } ?>
</div>
</div>
 <?php else : ?>
<div class="alert alert-danger">حدث خطاء! اذا استمرت المشكلة نرجوا تبليغ ادارة الموقع لتصحيحة</div> 
<?php endif; wp_reset_query(); ?>
<? /*End Content area Query*/ ?>


</div><!--home-->
</div><!--home-->



<? get_footer(); ?>