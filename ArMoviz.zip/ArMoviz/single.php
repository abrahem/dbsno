<? get_header(); ?>
<div class="Moveis-page">
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>

<div class="row card-movies">
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"style="text-align: center;">
<br/>
<?php if ( has_post_thumbnail() ) : ?> <?php the_post_thumbnail(''); ?><?php endif; ?>
<br/> 
<br/> 
</div>


<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 info">
<h4><?php  
          echo getPostViews(get_the_ID()); 
?></h4>
<?php if (get_the_title()):  ?>
<h4><i class="fa fa-film"></i> اسم الفيلم : <?php wp_title(); ?></h4>
<?php endif; ?>
<h4><i class="fa fa-history"></i> تاريخ الرفع : <?php echo get_the_date(); ?>-<?php echo get_the_time(); ?></h4>

<h4><i class="fa fa-lightbulb-o"></i> وصف قصير للاحداث : <?php the_content(); ?></h4>
</div>
</div>
<br/><br/><br/><br/><br/>
<div class="row">
<div class="col-lg-4 col-md-4 col-sm-12 hidden-xs"style="text-align: center;">
<div class=" card-movies">
<?php if (comments_open()) { ?>
                <!-- start post comments -->
                <?php comments_template( '', true ); ?>
				<!-- end post comments -->
                <?php } ?>
							<p><?php the_tags(); ?><?php single_tag_title();?></p>
</div>
</div>
<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 card-movies"style="text-align: center;">
<br/>
<div id="myTabContent" class="tab-content"> 
   <div class="tab-pane fade in active" id="server1"> 
<?php if (get_post_meta($post->ID, 'server1', TRUE)):  ?><?php echo get_post_meta($post->ID, 'server1', TRUE); ?><?php endif; ?>
   </div> 
   <div class="tab-pane fade" id="server2"> 
<?php if (get_post_meta($post->ID, 'server2', TRUE)):  ?><?php echo get_post_meta($post->ID, 'server2', TRUE); ?><?php endif; ?>
   </div> 
   <div class="tab-pane fade" id="server3"> 
<?php if (get_post_meta($post->ID, 'server3', TRUE)):  ?><?php echo get_post_meta($post->ID, 'server3', TRUE); ?><?php endif; ?>
   </div> 
   <div class="tab-pane fade" id="server4"> 
<?php if (get_post_meta($post->ID, 'server4', TRUE)):  ?><?php echo get_post_meta($post->ID, 'server4', TRUE); ?><?php endif; ?>
   </div> 

</div>
<br/>
<ul id="myTab" class="nav nav-tabs"> 
<?php if (get_post_meta($post->ID, 'server1', TRUE)):  ?><li class="active"><a href="#server1" data-toggle="tab"><i class="fa fa-play-circle"></i> السيرفر الاول</a></li><?php endif; ?>
<?php if (get_post_meta($post->ID, 'server2', TRUE)):  ?><li><a href="#server2" data-toggle="tab"><i class="fa fa-play-circle"></i> السيرفر الثاني</a></li><?php endif; ?>
<?php if (get_post_meta($post->ID, 'server3', TRUE)):  ?><li><a href="#server3" data-toggle="tab"><i class="fa fa-play-circle"></i> السيرفر الثالث</a></li><?php endif; ?>
<?php if (get_post_meta($post->ID, 'server4', TRUE)):  ?><li><a href="#server4" data-toggle="tab"><i class="fa fa-play-circle"></i> السيرفر الرابع HD</a></li><?php endif; ?>
</ul> 
<br/>
</div>
<div class="col-xs-12 hidden-lg hidden-sm hidden-md"style="text-align: center;margin-top: 20px;">
<div class=" card-movies">
<?php if (comments_open()) { ?>
                <!-- start post comments -->
                <?php comments_template( '', true ); ?>
				<!-- end post comments -->
                <?php } ?>
</div>
</div>
</div>
<?php endwhile; ?>
<?php else : ?>
<div class="alert alert-danger">حدث خطاء! اذا استمرت المشكلة نرجوا تبليغ ادارة الموقع لتصحيحة</div> 
<?php endif; ?>
</div>

<? get_footer(); ?>