
<!DOCTYPE html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8" <?php language_attributes(); ?>> <![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9" <?php language_attributes(); ?>> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" <?php language_attributes(); ?>> <!--<![endif]-->

<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title><?php wp_title( '|', true, 'right' ); ?> <?php bloginfo('name'); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="<? bloginfo('stylesheet_directory'); ?>/js/html5shiv.min.js"></script>
      <script src="<? bloginfo('stylesheet_directory'); ?>/js/respond.min.js"></script>
    <![endif]-->
      <script src="<? bloginfo('stylesheet_directory'); ?>/js/jquery.min.js"></script>
      <script src="<? bloginfo('stylesheet_directory'); ?>/js/bootstrap.min.js"></script>	      	      
      <script src="<? bloginfo('stylesheet_directory'); ?>/js/jquery.nicescroll.min.js"></script>
      <script src="<? bloginfo('stylesheet_directory'); ?>/js/jquery.nicescroll.js"></script>
 <!-- favicon -->
<?php global $data; ?>
<?php if (of_get_option('fav_douma')): ?>
<link rel="shortcut icon" href="<?php echo of_get_option('fav_douma'); ?>" title="Favicon" />
<?php else: ?>

<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon.ico" title="Favicon" />
<?php endif; ?>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<?php  wp_head(); ?>
</head>   
<body><!-- body -->
<div class="header">
<div id="particles-js"></div>
</div>
 <nav  class=" nim-menu navbar navbar-default ">
      <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
		  <a href="<?php echo home_url(); ?>"  title="<?php bloginfo('name'); ?>" 
		  data-toggle="tooltip" style="text-align: center;display: block;font-size: 30px;line-height: 27px;color: #e80651;" class="navbar-brand">
        <?php if (of_get_option('logo')):  ?><img src="<?php echo of_get_option('logo'); ?>"><?php else : ?>  <i class="fa fa-film fa-spin"></i> <?php echo of_get_option('name_logo', 'no entry'); ?><?php endif; ?></a>	
          </a><!---logo--->	
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
             <?php wp_nav_menu();?>
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container-fluid -->
    </nav>
<div class="container home">
   