﻿<?php global $data; ?>
</div>
<div class="footer">
<div class="row" style="margin: 0;">
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
<h3 style="color: #fff; text-align: center;font-size: 20px;"> Copyright ©  <a href="<?php echo home_url(); ?>"  title="<?php bloginfo('name'); ?>" style="text-decoration: none;"><?php bloginfo('name'); ?></a></h3>
</div>
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
<h3 style="color: #fff; text-align: center;font-size: 20px;">®Powered By Mahmoud Mansour <i class="fa fa-wordpress fa-spin"></i></h3>
</div>
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 social">

        <ul>
		 <?php if (of_get_option('social_fb')):  ?> <li><a href="<?php echo of_get_option('social_fb'); ?>" target="_blank"><i class="fa fa-facebook fb-icon"></i></a></li><?php endif; ?>
         <?php if (of_get_option('social_tw')):  ?> <li><a href="<?php echo of_get_option('social_tw'); ?>" target="_blank"><i class="fa fa-twitter tw-icon"></i></a></li><?php endif; ?>
         <?php if (of_get_option('social_in')):  ?> <li><a href="<?php echo of_get_option('social_in'); ?>" target="_blank"><i class="fa fa-instagram in-icon"></i></a></li><?php endif; ?>
         <?php if (of_get_option('social_gp')):  ?> <li><a href="<?php echo of_get_option('social_gp'); ?>" target="_blank"><i class="fa fa-google-plus gp-icon"></i></a></li><?php endif; ?>
		 <?php if (of_get_option('social_yt')):  ?> <li><a href="<?php echo of_get_option('social_ty'); ?>" target="_blank"><i class="fa fa-youtube-play yt-icon"></i></a></li> <?php endif; ?>  
         <?php if (of_get_option('social_pi')):  ?> <li><a href="<?php echo of_get_option('social_pi'); ?>" target="_blank"><i class="fa fa-linkedin pi-icon"></i></a></li><?php endif; ?>
		</ul>	
</div>

</div><!---/row--->
</div><!---/footer--->
<script> 
   $(function(){ 
      $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) { 
      // Get the name of active tab 
      var activeTab = $(e.target).text();     
	  // Get the name of previous tab 
      var previousTab = $(e.relatedTarget).text();  
      $(".active-tab span").html(activeTab); 
      $(".previous-tab span").html(previousTab); 
   }); }); </script> 
   <script> 
   $(function () { $("[data-toggle='tooltip']").tooltip(); });      
   </script> 

<script>
  $(document).ready(function() {
  
	var nice = $("html").niceScroll();  // The document page (body)
	
	$("#div1").html($("#div1").html()+' '+nice.version);
    
    $("#boxscroll").niceScroll({cursorborder:"",cursorcolor:"#00F",boxzoom:true}); // First scrollable DIV

    $("#boxscroll2").niceScroll("#contentscroll2",{cursorcolor:"#F00",cursoropacitymax:0.7,boxzoom:true,touchbehavior:true});  // Second scrollable DIV
    $("#boxframe").niceScroll("#boxscroll3",{cursorcolor:"#0F0",cursoropacitymax:0.7,boxzoom:true,touchbehavior:true});  // This is an IFrame (iPad compatible)
	
    $("#boxscroll4").niceScroll("#boxscroll4 .wrapper",{boxzoom:true});  // hw acceleration enabled when using wrapper
    
  });
</script>

<?php wp_footer(); ?>
</body>
</html>
