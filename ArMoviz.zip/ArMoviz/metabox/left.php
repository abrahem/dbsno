<div class="leftSide">
    	<div class="topTitle">
        	<h2>جديد الالعاب</h2>
            <?php if(function_exists('tare2_pagination')) : ?>
          <?php tare2_pagination() ?>
          <?php else : ?>
          <div class="alignleft">
            <?php previous_posts_link(__('التدوينات الحديثة &raquo;','arclite')) ?>
          </div>
          <div class="alignright">
            <?php next_posts_link(__('&laquo; التدوينات السابقة','arclite')) ?>
          </div>
          <div class="clear"></div>
          <?php endif; ?>
        </div>
        <div id="effect-6" class="effects games">
        	<?php if(have_posts()) : while(have_posts()) : the_post(''); ?>
            <div class="divGame">
            	<div class="gemeImg img">
                	<?php the_post_thumbnail('thumbnail'); ?>
                	<div class="overlay">
                        <a href="<?php the_permalink(); ?>" class="expand">+</a>
                        <a class="close-overlay hidden">x</a>
                	</div>
                </div>
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            </div>
            <?php endwhile; ?>
			<?php else : ?>
            <p>عذراً ما تبحث عنه غير متوفق , , قم بالبحث بكلمات أخري . </p>
            <br />
            <?php endif; ?>
            <?php wp_reset_query(); ?>
        </div>
		
		
		
	<?php
//for each category, show 5 posts
$cat_args=array(
  'orderby' => 'name',
  'order' => 'ASC'
   );
$categories=get_categories($cat_args);
  foreach($categories as $category) { 
    $args=array(
      'showposts' => 5,
      'category__in' => array($category->term_id),
      'caller_get_posts'=>1
    );
    $posts=get_posts($args);
      if ($posts) {
	 
        echo '<p>Category: <a href="' . get_category_link( $category->term_id ) . '" title="' . sprintf( __( "View all posts in %s" ), $category->name ) . '" ' . '>' . $category->name.'</a> </p> ';
        foreach($posts as $post) {
          setup_postdata($post); ?>
          <p><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></p>
          <?php
        } // foreach($posts
		 
      } // if ($posts
    } // foreach($categories
?>


    </div>