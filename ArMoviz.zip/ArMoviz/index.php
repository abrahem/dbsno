<? get_header(); ?> 		
<div class="row">

<?php while ( $wp_query->have_posts() ) : $wp_query->the_post();?>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6" style="margin-bottom: 20px;">
<div class="card-home">

<a href="<?php the_permalink(); ?>">
<?php the_post_thumbnail(); ?>

<div class="row col-lg-12">
<h4><i class="fa fa-film"></i>  <?php the_title(); ?> </h4>
</div>
</a>
</div><!---/card-home--->
</div>	

<?php endwhile; ?>

</div>	


<div class="num-page">
<div class="row">
<?php if (function_exists("pagination")) {
		 pagination($additional_loop->max_num_pages);
		 } ?>
</div>
</div>
<? get_footer(); ?> 
