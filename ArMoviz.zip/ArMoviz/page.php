<? get_header(); ?>
<div class="card-movies">
<div class="row">
<?php if (get_the_title()):  ?>
<h4 class="col-lg-12">
<?php wp_title(); ?>
</h4>
<?php endif; ?>

<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<?php if ( has_post_thumbnail() ) : ?>
	<a class="img2" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
	<?php the_post_thumbnail(''); ?>
	</a>
<?php endif; ?>
<?php the_content(); ?>
<?php endwhile; ?>
<?php else : ?>
<div class="alert alert-danger">حدث خطاء! اذا استمرت المشكلة نرجوا تبليغ ادارة الموقع لتصحيحة</div> 
<?php endif; ?>
</div>
</div>
<? get_footer(); ?>